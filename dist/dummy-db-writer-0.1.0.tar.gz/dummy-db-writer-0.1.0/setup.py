# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['Faker>=15.0.0,<16.0.0',
 'PyMySQL>=1.0.2,<2.0.0',
 'PyPika>=0.48.9,<0.49.0',
 'click>=8.1.3,<9.0.0']

entry_points = \
{'console_scripts': ['writer = src.app:dummy_writer']}

setup_kwargs = {
    'name': 'dummy-db-writer',
    'version': '0.1.0',
    'description': 'Populate your DB with dummy data easily',
    'long_description': '# dummy_db_writer',
    'author': 'Jorge Alves',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
